# Instructions
```
npm i
npm run start
```
# Features
- All minimum behaviors
  - Filters are
    - all: everything not deleted
    - inprogess: not done, also not deleted
    - done: done,  also not deleted
    - starred: everything with a star, also not deleted
    - deleted: things marked deleted
      - this is an archive page where you can see if you truly want to remove items you have marked deleted
- Comments and description advanced feature
  - These are seen by pressing the edit button on any task, editing is at the top of the page and comments are below it
- Full Accounts
  - Login / logout
  - account creation
  - encrypted passwords with bcrypt


# Important URLs
- Main Page http://localhost:4131/
- Create Page http://localhost:4131/create Accessible with the create button in the bottom right of the main page
- Account Page http://localhost:4131/account Accessible with the account button on the top right of the navbar
- Edit / Expanded Page http://localhost:4131/task/id Accessible with the edit button on any task

# Resolutions
Should work on anything bigger than 550x550
Tested mostly on 1600x1000

# Notes
You can use the accounts below for testing, or make your own (username, password)
- admin, admin
- user, example

I did most of my testing on admin, admin

I use the words task and note interchangeably in some places in the code

When you load the main page it sends everything at once in the first query, then it does not request the content again unless you manually reload or get to the page from another place.
All the changes to filters and done / starred are done without reloading everything. I thought this was a good approach because it meant once the website was loaded you could mess around with done and filters with no overhead.

I did not write front_grid.js, that is the file that puts each task in the brick/masonry style and I got it from [link](https://medium.com/@andybarefoot/a-masonry-style-layout-using-css-grid-8c663d355ebb)

CREATION TIME and DEADLINE in the database are not being used for anything in this version