document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("logo").addEventListener("click", () => {
        window.location.href = "/";
    });
})

